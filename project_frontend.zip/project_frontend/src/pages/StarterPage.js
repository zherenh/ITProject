import React from 'react'
import Starter from '../components/Starter/Starter'

const StarterPage = () => {
	return (
		<div>
			<Starter></Starter>
		</div>
	)
}

export default StarterPage
