import React from 'react'
import Modify from '../components/Modify/Modify'

const ModifyPage = () => {
  return (
    <div>
        <Modify></Modify>
    </div>
  )
}

export default ModifyPage