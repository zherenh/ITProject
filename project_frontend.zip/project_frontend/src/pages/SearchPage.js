import React from 'react'
import Search from '../components/Search/Search'

const SearchPage = () => {
  return (
    <div>
      <Search></Search>
    </div>
  )
}

export default SearchPage
