import React from 'react'
import Add from '../components/Add/Add'

const AddPage = () => {
  return (
    <Add></Add>
  )
}

export default AddPage
