import React from 'react'

const DataContext = React.createContext({

});

export default DataContext;