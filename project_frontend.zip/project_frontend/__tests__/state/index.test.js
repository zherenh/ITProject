describe('数字加减算术运算', () => {
  test('3加2减5等于0', () => {
    expect(3 + 2 - 5).toBe(0)
  })
})